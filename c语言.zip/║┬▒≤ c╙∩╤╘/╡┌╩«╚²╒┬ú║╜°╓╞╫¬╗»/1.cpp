#include <stdio.h>
int main()
{
	unsigned char a=0;
	while (++a!=0)
	{
		
	}
	printf("%d\n",a);
	printf("%d\n",a-1);
 } 
