#include <stdio.h>
int main()
{
	int *p;
	*p = 5;
	printf("%d\n",*p);
	return 0;
}
