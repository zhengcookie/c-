#include <stdio.h>
int main()
{
	int i = 1000;
	printf("%#X",i);
	return 0;
}
