/*
		������Ԫ�ص������ 
*/ 

#include <stdio.h>
int main()
{
	int a[8] = {1,2,3,4,5,6,7,8};
	int i,j;
	i = 0;
	j = 7;
	int t;
	while (i<j)
	{
		t = a[i];
		a[i] = a[j];
		a[j] = t;
		i++;
		j--;
	}
	for (i=0; i<sizeof(a)/sizeof(a[0]); i++)
	{
		printf("%d\n",a[i]);
	}
	return 0;
	/*
	{
		int i;
		for (i=6; i>-1; i--)
		{
			printf("%d ",a[i]);
		}
	}
	*/
	
}
