/*
	ʱ�䣺2023.7.14 14.25�� 
*/
#include <stdio.h>
int main(void)
{
	int a[5];
	int i;
	for (i=0; i<sizeof(a)/sizeof(a[0]);i++)
	{
		scanf("%d",&a[i]);
		printf("%d\n",a[i]);		
	}
	{
		int x;
		for(x=0; x<sizeof(a)/sizeof(a[0]); x++)
		printf("%d ",a[x]);
	}
	return 0;
}
