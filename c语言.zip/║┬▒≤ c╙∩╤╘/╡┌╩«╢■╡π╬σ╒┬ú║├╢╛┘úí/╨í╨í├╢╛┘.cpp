#include <stdio.h>
enum weekday
{
 	 monday,tuesday,wednesday,thursday,friday,saturday,sunday,
 	 

};
void f(enum weekday day)
{
	switch (day)	
	{
	case 0:
		printf("monday\n");
		break;
	case 1:
		printf("tuesday\n");
		break;
	case 2:
		printf("wednesday\n");
		break;
	case 3:
		printf("thursday\n");
		break;
	case 4:
		printf("friday\n");
		break;
	case 5:
		printf("saturday\n");
		break;
	case 6:
		printf("sunday\n");
		break;
	}
}
int main()
{
	
 	f(sunday);
 	return 0;
 } 
