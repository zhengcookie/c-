#include <stdio.h>
int main()
{
	int i;
	scanf("%d",&i);
	while (i = getchar() != '\n')
	{
		continue;
	}

	printf("%d\n",i);
	
	return 0;
}

