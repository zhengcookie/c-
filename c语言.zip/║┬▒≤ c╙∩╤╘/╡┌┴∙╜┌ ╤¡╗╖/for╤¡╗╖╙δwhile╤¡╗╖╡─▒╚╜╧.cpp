
#include <stdio.h>
int main()
{
	int i;
	int sum = 0;
	{
//		for (i=1; i<101; i++){
//			sum += i;
//		}
	}
	while (i < 101){
		sum += i;
		i ++;
	}
	printf("%d\n",sum);
}
