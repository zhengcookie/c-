#include <stdio.h>
#include <stdlib.h>
int main()
{
	int i = 3;
	int *p = &i;

	printf("%d\n",*p); 
}
