#include <stdio.h>
void array(int * p, int len)
{
	int i;
	for (i=0;i<len;i++)
	{
		printf("%d\n",p[i]);
	}
}
int main()
{
	int a[5] = {1,2,3,4,5};
	array(a,5);			//a == &a[0] 
	
	return 0;
	
}
