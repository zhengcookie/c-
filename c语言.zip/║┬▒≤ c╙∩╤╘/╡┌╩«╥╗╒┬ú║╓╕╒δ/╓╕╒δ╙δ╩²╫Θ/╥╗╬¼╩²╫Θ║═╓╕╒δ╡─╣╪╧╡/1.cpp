//#include <stdio.h>
//int main()
//{
//	int i = 2;
//	double j = 2.0;
//	scanf("%d\n%lf",&i,&j);
//	printf("%d %lf",i,j);
//	
//	return 0;
//}
