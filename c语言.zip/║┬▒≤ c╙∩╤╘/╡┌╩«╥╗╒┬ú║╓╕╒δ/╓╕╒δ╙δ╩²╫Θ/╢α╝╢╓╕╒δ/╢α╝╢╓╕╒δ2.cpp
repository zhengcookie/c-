#include <stdio.h>
void f(int **q)
{
	int i = 5;
	*q = &i;
	//*q����p

	

	 
}

void g()
{
	int i =10;
	int *p = &i;
	
	f(&p);	//p��int * , &pΪ int **  
	printf("%d\n",*p);
	printf("%d\n",*p);

	
}

int main()
{
	g(); 
	return 0;
 } 
