//#include <stdio.h>
//#include <malloc.h>
//int k = 7;
//void f(int **s)
//{
//	int *t ;
//	t = &k;	// t = 7;
//	*s = t;			//*s = 7
//	printf("%d %d %d ",k,*t,**s);//7 7 7
//}
//int main()
//{
//	int i = 3;
//	int *p = &i;
//	int **r = &p;
//	f(&p);//�����ֵ��**r,*r = &i  **r = i,
//	printf("%d %d %d\n",i,*p,**r); //3 7 7 
//}

#include <stdio.h>
int main()
{
	char a[5] = "���";
	printf("%c",a[0]);
 } 
