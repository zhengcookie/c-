# include <stdio.h>
//int f(int i, int j)
//{
//	return j;
//
//}
//int f1(int i, int j)
//{
//	return i;
//}
void g(int * p, int * q)
{
	*p = 1;
	*q = 2;
	
}
int main()
{
	int a = 3;
	int b = 5;
	g(&a , &b);
	
	printf("a = %d b =%d\n",a, b);
	
	return 0;
}
