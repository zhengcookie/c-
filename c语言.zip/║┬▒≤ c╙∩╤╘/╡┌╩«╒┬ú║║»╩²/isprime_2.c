/*
    时间：2023.7。22
    目的：求1到对应数字之间的素数
    探究：这样写不好，可以使用多个函数进行封装

*/
#include <stdbool.h>
#include <stdio.h>

int main()
{
    int i;
    int val;
    int j;
    scanf("%d",&val);
    for (i=2; i<val; i++)
    {
        for (j=2; j<i; j++)
        {
            if (i % j == 0)
            break;
        }
        if (i == j)
        {
            printf("%d ",i);
        }
    }
    return 0;
}