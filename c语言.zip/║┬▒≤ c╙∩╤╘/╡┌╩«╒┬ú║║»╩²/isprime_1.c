/*
    时间：2023.7。22
    目的：求一个数字是否为素数
    

*/
#include <stdbool.h>
#include <stdio.h>
bool isprime(int m)
{
    int i;
    for (i=2; i<m; i++)   //i = 2,因为素数从2开始
    {
        int j;
        if (m % i == 0)   
        //必须知道一件事情。每次for循环val都会比i要大 所以是4 % 1 4 % 2，检索到break后就退出
            break;
    }
    if (i == m)
        return true;
    else                    
        return false;
}
int main()
{
    int val;
    scanf("%d",&val);
    if (isprime(val))
    {
        printf("yes\n");
    }
    else
    {
        printf("no\n");
    }
}