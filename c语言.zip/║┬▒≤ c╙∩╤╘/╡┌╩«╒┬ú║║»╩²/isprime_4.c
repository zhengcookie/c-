/*
    时间：2023.7。22
    目的：求1到对应数字之间的素数
    探究：这样写，更加模块化

*/
#include <stdbool.h>
#include <stdio.h>

bool Isprime(int m)
{   
    int i;
    for (i=2; i<m; i++)
    {
        if (m % i == 0)
            break;  
    }

    if (i == m)
        return true;
    else
        return false;
    
}

void TraverseVal(int n)
{
    int i;
    for (i=2; i<n; i++)
    {
        if (Isprime(i))
        printf("%d ",i);
    }
}

int main()
{
    int i;
    int val;
    scanf("%d",&val);
    TraverseVal(val);
    
    return 0;
}