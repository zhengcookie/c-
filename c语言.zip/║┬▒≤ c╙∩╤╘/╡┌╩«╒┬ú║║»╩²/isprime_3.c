/*
    时间：2023.7。22
    目的：求1到对应数字之间的素数
    探究：这样写不好，可以更加模块化

*/
#include <stdbool.h>
#include <stdio.h>
bool isprime(int m)
{   
    int i;
    for (i=2; i<m; i++)
    {
        if (m % i == 0)
            break;  
    }

    if (i == m)
        return true;
    else
        return false;
    
}


int main()
{
    int i;
    int val;
    scanf("%d",&val);
     for (i=2; i<val; i++)
     {
        if (isprime(i))
            printf("%d ",i);
     }
    
    return 0;
}