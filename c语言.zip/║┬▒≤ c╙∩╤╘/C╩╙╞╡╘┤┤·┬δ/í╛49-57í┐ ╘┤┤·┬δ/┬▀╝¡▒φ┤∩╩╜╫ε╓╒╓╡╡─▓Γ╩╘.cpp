# include <stdio.h>

int main(void)
{
	float score = 0;

	int i = (90<=score<=100);

	printf("%d\n", i);

	return 0;
}