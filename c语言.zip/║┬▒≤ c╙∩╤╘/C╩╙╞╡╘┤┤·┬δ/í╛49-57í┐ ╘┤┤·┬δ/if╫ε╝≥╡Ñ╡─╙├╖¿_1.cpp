# include <stdio.h>

int main(void)
{
	if (3 > 2)
		printf("AAAA\n");

	return 0;
}