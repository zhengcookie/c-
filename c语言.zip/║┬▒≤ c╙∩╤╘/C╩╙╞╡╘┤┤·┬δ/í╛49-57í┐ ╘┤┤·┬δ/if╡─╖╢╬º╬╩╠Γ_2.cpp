# include <stdio.h>

int main(void)
{
	if (4 > 2)
	{
		printf("AAAA\n");
		printf("BBBB\n");
	}
	
	printf("CCCC\n");

	return 0;
}

