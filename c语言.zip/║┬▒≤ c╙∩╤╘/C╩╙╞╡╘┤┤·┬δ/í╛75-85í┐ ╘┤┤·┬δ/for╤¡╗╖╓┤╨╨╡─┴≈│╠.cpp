for (1; 2; 3)
	for (4; 5; 6)
		A;
		B;
	