# include <stdio.h>

int main(void)
{
	int i;
	char ch;

	scanf("%d", &i);
	printf("i = %d\n", i);
	scanf("%c", &ch);
	printf("ch = %c\n", ch);

	return 0;
}