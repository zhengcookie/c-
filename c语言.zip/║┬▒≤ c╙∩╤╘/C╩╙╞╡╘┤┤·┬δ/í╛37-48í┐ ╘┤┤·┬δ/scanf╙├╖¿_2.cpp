# include <stdio.h>

int main(void)
{
	int i, j;

	scanf("%d %d", &i, &j);
	printf("i = %d, j = %d\n", i, j);

	return 0;
}