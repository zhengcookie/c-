# include <stdio.h>

int main(void)
{
	int i = 33;

	printf("i = %#X\n", i);

	return 0;
}

