# include <stdio.h>

int main(void)
{
//	int i = -5;
//	printf("%#X\n", i);

//	int j = 0xFFFFFFF5;
//	printf("%d\n", j);

	char ch = 0x80;
//	printf("%d\n", ch);

	ch = 129;// 1000 0000
	printf("%d\n", ch);

	return 0;
}