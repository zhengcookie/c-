/*
if (x >= 0)
if (x > 0)
	y = 1;
else
	y = 0;
*/

# include <stdio.h>

int main(void)
{
/*
	if (x >= 0)
	{
		if (x > 0)
			y = 1;
		else
			y = 0;
	}
*/
	int * p;

	*p = 5;

	return 0;
}