# include <stdio.h>

int main(void)
{
	int i;

	printf("i = %f\n", i);  //int %d  char %c  flaot %f double %lf  long int %ld

	return 0;
}