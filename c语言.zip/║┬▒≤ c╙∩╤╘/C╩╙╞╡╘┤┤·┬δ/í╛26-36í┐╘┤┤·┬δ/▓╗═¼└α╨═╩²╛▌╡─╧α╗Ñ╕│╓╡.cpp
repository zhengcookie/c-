# include <stdio.h>

int main(void)
{
	int i = 2147483649;

	printf("i = %d\n", i);

	return 0;
}