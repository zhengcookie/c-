# include <stdio.h>

int main(void)
{
//	int i = -100;
//	printf("%#X\n", i); 

	int j = 0xFFFFFFCA;
	printf("%d\n", j);
	return 0;
}
//1001010