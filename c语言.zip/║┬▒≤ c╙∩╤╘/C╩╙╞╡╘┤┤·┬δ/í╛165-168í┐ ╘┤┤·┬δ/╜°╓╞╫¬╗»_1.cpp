# include <stdio.h>

int main(void)
{
	int i = 1000;
	printf("%#X\n", i);
	return 0;
}