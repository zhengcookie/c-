# include <stdio.h>

void f(int i, float x)
{
	printf("%d\n", i);
}

int main(void)
{
	f(9.9, 6.6);

	return 0;
}
