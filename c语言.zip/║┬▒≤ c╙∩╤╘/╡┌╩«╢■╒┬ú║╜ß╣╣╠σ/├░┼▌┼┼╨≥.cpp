#include <stdio.h>
#include <malloc.h>

void add(int *p,int len);
void sort(int * pArr, int len);
void output(int *a,int j);
int main()
{
	int i,j=6;
	int *a = (int *)malloc(sizeof(int)*j);
	add(a,j);
	sort(a,j);
	output(a,j);
	
	return 0;
}
void add(int *p,int len)
{
	int i;
	for (i = 0; i < len; i++)
	{
		scanf("%d",&p[i]);
	}
}
void sort(int * pArr, int len)
{
	int i, j, t;
	for (i=0; i<len-1; i++)	
		//��i����0,	i<6-1-0=5,	j��ִ��
		//i=1,		i<6-1=5,	jִ��6-1-1=4�� 
		//i=2,		i<6-1=5,	jִ��6-1-2=3��
		//....
		//�Դ����� 
		 
	{
		for (j=0; j<len-1-i; j++)//j=0
		{
			if (pArr[j] > pArr[j+1])
			{
				t = pArr[j];
				pArr[j] = pArr[j+1];
				pArr[j+1] = t;
			}
		}
	 } 
}
void output(int *a,int j)
{
	int i;
	for (i = 0; i < j; i++)
	{
		printf("%d ",a[i]);
	}
	printf("\n");
}
