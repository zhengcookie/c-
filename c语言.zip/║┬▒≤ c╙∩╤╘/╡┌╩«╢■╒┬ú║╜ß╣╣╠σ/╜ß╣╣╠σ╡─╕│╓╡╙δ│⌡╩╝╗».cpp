#include <stdio.h>

struct Student
{
	int age;
	float score;
	char sex[100];
};

int main()
{
	struct Student st = {80, 66.6, "��"};//��ʼ�� �����ͬʱ����ֵ
	struct Student st2;
	st2.age = 10;
	st2.score = 88;
	st2.sex = "Ů";
	 
	printf("%d %d %d\n",st.age,st.score,st.sex);
	printf("%d %d %d\n",st2.age,st2.score,st2.sex);
	return 0;
}
