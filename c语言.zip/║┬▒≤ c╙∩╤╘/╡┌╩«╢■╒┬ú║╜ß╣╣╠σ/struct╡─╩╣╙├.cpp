#include <stdio.h>

struct Student
{
	int age;
	float score;
	char sex[100];
};

int main()
{
	struct Student st = {80, 66.6, "��"};
	
	return 0;
}
