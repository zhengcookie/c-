#include <stdio.h>

//��һ�ַ�ʽ 
struct Student
{
	int age;
	float score;
	char sex[100];
};
//�ڶ��ַ�ʽ
struct Student2
{
	int age;
	float score;
	char sex[100];
} st2;

//�����ַ�ʽ
struct 
{
	int age;
	float score;
	char sex[100];
} st3; 
int main()
{
	struct Student st = {80, 66.6, "��"};
	
	return 0;
}
